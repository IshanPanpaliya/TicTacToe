package com.company;

public class Player1 {
    public boolean turn;

    public Player1() {
        turn = true;
    }
}
